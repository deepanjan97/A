package com.nil.ba.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;

import com.nil.ba.beans.Customer;

public interface IBank_Application_Dao {
	public HashSet<Customer> Create_Acc(Customer c);
	public int showBalance(int Acc_No);
	public HashSet<Customer> deposit(int account,int amount);
	public HashSet<Customer> withdraw(int account,int amount);
	public LinkedHashSet<String> print_Trans(String s);
	public HashSet<Customer> fund_Transfer(int acc1,int acc2,int amt1);


}
