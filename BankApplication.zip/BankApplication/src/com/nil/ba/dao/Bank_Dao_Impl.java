/**
 * 
 */
/**
 * @author NILANSAH
 *
 */
package com.nil.ba.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

import com.nil.ba.beans.Customer;
import com.nil.ba.util.StoringObj;

public class Bank_Dao_Impl implements IBank_Application_Dao{
	StoringObj obj =new StoringObj();
	ArrayList<String> al =new ArrayList<>();
	
	
	public HashSet<Customer> Create_Acc(Customer c) {
		HashSet<Customer> ald=obj.storeObj(c);
		return ald;
	}
	
	public int showBalance(int Acc_No) {
		obj.checkBal(Acc_No);
		return obj.checkBal(Acc_No);
		
	}
	public HashSet<Customer> deposit(int Account_No,int amount){
		HashSet<Customer> cd=obj.Deposit(Account_No, amount);
		return cd;
		
	}

	@Override
	public HashSet<Customer> withdraw(int account, int amount) {
		// TODO Auto-generated method stub
		HashSet<Customer> cw =obj.withDraw(account, amount);
		return cw;
	}

	@Override
	public LinkedHashSet<String> print_Trans(String s) {
		
		return obj.printu_Trans(" ");
	}


	@Override
	public HashSet<Customer> fund_Transfer(int acc1,int acc2,int amt1) {
		// TODO Auto-generated method stub
		HashSet<Customer> fd=obj.withDraw(acc1, amt1);
		fd=obj.Deposit(acc2, amt1);
		//HashSet<Customer> fd=obj.fundTrans(acc1, acc2, amt1);
		return fd;
	}
}