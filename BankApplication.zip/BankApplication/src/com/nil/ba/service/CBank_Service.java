/**
 * 
 */
/**
 * @author NILANSAH
 *
 */
package com.nil.ba.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.nil.ba.beans.Customer;
import com.nil.ba.dao.Bank_Dao_Impl;
import com.nil.ba.exception.BankException;

public class CBank_Service implements Bank_Service{
	Bank_Dao_Impl bdi =new Bank_Dao_Impl();
	HashSet<String> al /*=new ArrayList<>()*/;
	

	@Override
	public int showBalance(int Acc_no) {
		//bdi.showBalance(Acc_no);
		return bdi.showBalance(Acc_no);
	}

	@Override
	public HashSet<Customer> deposit(int account,int amount) {
		HashSet<Customer> sd =bdi.deposit(account, amount);
		return sd;
		
	}

	@Override
	public LinkedHashSet<String> print_Trans(String s) {
		
		return (bdi.print_Trans(" "));
	}

	@Override
	public HashSet<Customer> fund_Transfer(int acc1,int acc2,int amt1) {
			HashSet<Customer> fd =bdi.fund_Transfer(acc1, acc2, amt1);
			return fd;
		// TODO Auto-generated method stub
		
	}
	public HashSet<Customer> Create_Acc(Customer cust) {
		HashSet< Customer> a1=bdi.Create_Acc(cust);
		return a1;
	}

	@Override
	public HashSet<Customer> withdraw(int Account_No, int amount) {
		// TODO Auto-generated method stub
		HashSet<Customer> sw=bdi.withdraw(Account_No, amount);
		return sw;
	}
	

	public ArrayList<String> validateDetails(Customer c) throws BankException{
		ArrayList<String> val =new ArrayList<>();
		if(!(isName(c.getCust_Name()))) {								//validating the details.
			val.add("customer name is not in valid format ");
		}
		if(!(isCellNo(c.getCust_cellNo()))) {
			val.add("Customer cell No. is invalid format");
		}
		if(!(isAcc_type(c.getCust_Type()))){
			val.add("Customer Account type is invaliid format ");
		}
		return val;
	}
	public boolean isAcc_type(String type) {
		if(type.equalsIgnoreCase("savings") || type.equalsIgnoreCase("current"))
			return true;
		else
			return false;
	}
	public boolean isName(String s) {
		Pattern patName =Pattern.compile("^[A-Z]{1}[a-z]{2,}$");
		Matcher mat = patName.matcher(s);
		return mat.matches();
	}
	public boolean isCellNo(String cell) {
		Pattern patName =Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher mat = patName.matcher(cell);
		return mat.matches();
		
	}
	public boolean isAccountSer(int acnt) {						//validating account no. given by only user
		String s=String.valueOf(acnt);
		Pattern pat=Pattern.compile("^[1]{1}[0-9]{5}$");
		Matcher mat =pat.matcher(s);
		return mat.matches();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public int dep(int acc,int amt,HashSet<Customer> l) {
		Iterator<Customer> i =l.iterator();
		Customer c = null;
		while(i.hasNext()) {
			 c=i.next();
			if(c.getCust_Acc_No()==acc) {
				c.setBalance(c.getBalance()+amt);
				break;
			}
		}
		return (c.getBalance());
		
	}
	public int wit(int acc,int amt,HashSet<Customer> l) {
		Iterator<Customer> i =l.iterator();
		Customer c = null;
		while(i.hasNext()) {
			 c=i.next();
			if(c.getCust_Acc_No()==acc) {
				c.setBalance(c.getBalance()-amt);
				break;
			}
		}
		return (c.getBalance());
		
	}
	
}
		