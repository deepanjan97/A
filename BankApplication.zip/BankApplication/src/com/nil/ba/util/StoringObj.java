package com.nil.ba.util;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

import com.nil.ba.beans.Customer;

public class StoringObj {
	Customer c1=new Customer("Nil", 100050, "SAVINGS", "8274985471", "kOL", 5000);
	Customer c2=new Customer("Nilanjan", 100051, "current", "7003242832", "kOL", 2000);
	Customer c3 =new Customer("adi", 100053, "current", "8022147956", "hydre", 4000);
	Customer cust;
	
	
	HashSet<Customer> lis =new HashSet<>();
	
	public StoringObj() {
		lis.add(c1);
		lis.add(c2);
		lis.add(c3);
		//super();
		// TODO Auto-generated constructor stub
		/*lis.add(new Customer("NIL", 254, "current", 26515465, "Kolkata"));
		lis.add(new Customer("Sugu", (int)Math.random()*100+100, "savings", 958745455, "chennai"));*/
	}
	public HashSet<Customer> storeObj(Customer c) {
		lis.add(c);
		return lis;
		
		
	}
	
	
	public void viewAll() {
		System.out.println(lis);					
	}
	
	public int checkBal(int Acc_No) {
		Iterator<Customer> ic=lis.iterator();
		while(ic.hasNext()) {
			cust=ic.next();
			if(cust.getCust_Acc_No()==Acc_No) {
				//System.out.println("Balance is : "+cust.getBalance());
				return cust.getBalance();
			}
			else
				System.out.println("Account_No is not matched");
		}
		return 0;
	}
	
	
	public HashSet<Customer> Deposit(int acc,int amt){
		
		if(amt!=0) {
			Iterator<Customer> ic=lis.iterator();
			while(ic.hasNext()) {
				cust=ic.next();
				if(cust.getCust_Acc_No()==acc) {
					cust.setBalance(cust.getBalance()+amt);
					lis.add(cust);
					System.out.println("Deposit Successfull to "+cust.getCust_Acc_No());
					printu_Trans("you have deposited "+amt+" into your account "+acc+"\n Balance is = "+cust.getBalance());
					return lis;
				}else
					System.out.println("Account No. is not present");
		}
		
		return lis;
		
	}
		else {
			System.out.println("Amount is Undefined");
			return lis;
		}
		

}
	public HashSet<Customer> withDraw(int acc,int amt){
		
		if(amt!=0) {
			Iterator<Customer> ic=lis.iterator();
			while(ic.hasNext()) {
				cust=ic.next();
				if(cust.getCust_Acc_No()==acc) {
					if(amt<cust.getBalance()) {
					cust.setBalance(cust.getBalance()-amt);
					lis.add(cust);
					System.out.println("Withdrawn Successfull from "+cust.getCust_Acc_No());
					printu_Trans("you have withdrawn "+amt+" from your account "+acc+ " \nBalance is = "+cust.getBalance());
					return lis;
					}
					else
					{
						System.out.println("Balance is Insufficient to Withdraw:");
						System.out.println("Enter a valid amount ");
						return lis;
					}
				}
				else
					System.out.println("Account No. not found");
		}
		
		return lis;
		
	}
		else {
			System.out.println("Amount is Undefined");
			return lis;
		}

}
	
	/*public HashSet<Customer> fundTrans(int acc1,int acc2,int amt1) {
		if(amt1==0) {
			System.out.println("Enter a valid amount");
		}
		else
		{
			Iterator<Customer> ic=lis.iterator();
			while(ic.hasNext()) {
				cust=ic.next();
				if(cust.getCust_Acc_No()==acc1 && cust.getCust_Acc_No()==acc2) {
					if(cust.getCust_Acc_No()==acc1) {
						cust.setBalance(cust.getBalance()-amt1);
						lis.add(cust);
						if(cust.getCust_Acc_No()==acc2) {
							cust.setBalance(cust.getBalance()+amt1);
							lis.add(cust);
							return lis;
						}
					}
					
					
				}
			else
				{
					System.out.println("Error");
					System.out.println("Account no is not matched");
					return lis;
				}
		}
		
	}
	return lis;
}*/
	LinkedHashSet<String> ap =new LinkedHashSet<>();
	public LinkedHashSet<String> printu_Trans(String s) {
		
		ap.add(s);
		//System.out.println(ap);
		return ap;
	}

}