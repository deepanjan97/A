package com.cg.PageBean;

/**
 * 
 * @author Deepanjan Maji
 * @version 1.0
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

//This is the POM for Success Page
public class SuccessPage 
{

	WebDriver driver;
	
	@FindBy(xpath = "/html/body/h1")
	@CacheLookup
	WebElement sHeader;

	public SuccessPage(WebDriver driver) 
	{
		this.driver = driver;
	}

	public String getsHeader() 
	{
		return sHeader.getText();
	}

	public void setsHeader(WebElement sHeader) 
	{
		this.sHeader = sHeader;
	}
	
	
	
	
}
