package com.cg.PageBean;

/**
 * 
 * @author Deepanjan Maji
 * @version 1.0
 */

//This is the POM for Contact Us Page
public class ContactUsPage 
{

}
