package com.cg.PageBean;

/**
 * 
 * @author Deepanjan Maji
 * @version 1.0
 */

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

//This is the POM for Registration Page
public class RegistrationPage 
{
	WebDriver driver;
	
	@FindBy(name = "emp_name")
	@CacheLookup
	WebElement empName;
	
	@FindBy(name = "num")
	@CacheLookup
	WebElement empNumber;
	
	@FindBy(name = "S2")
	@CacheLookup
	WebElement empAddress;
	
	@FindBy(name = "txtFName1")
	@CacheLookup
	WebElement empContact;
	
	@FindBy(name = "location")
	@CacheLookup
	WebElement empLocation;
	
	@FindBy(name = "mydropdown")
	@CacheLookup
	WebElement empDesig;
	
	@FindBy(name = "email_id")
	@CacheLookup
	WebElement empEmail;
	
	@FindBy(name = "B4")
	@CacheLookup
	WebElement submitButton;
	
	@FindBy(name = "B5")
	@CacheLookup
	WebElement resetAll;

	public RegistrationPage(WebDriver driver) 
	{
		this.driver = driver;
	}

	public WebElement getEmpName() {
		return empName;
	}

	public void setEmpName(String eName) {
		this.empName.sendKeys(eName);
	}

	public WebElement getEmpNumber() {
		return empNumber;
	}

	public void setEmpNumber(String eNumber) {
		this.empNumber.sendKeys(eNumber);
	}

	public WebElement getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String eAddress) {
		this.empAddress.sendKeys(eAddress);
	}

	public WebElement getEmpContact() {
		return empContact;
	}

	public void setEmpContact(String eContact) {
		this.empContact.sendKeys(eContact);
	}

	public WebElement getEmpLocation() {
		return empLocation;
	}

	public void setEmpLocation(String eLocation) {
		this.empLocation.sendKeys(eLocation);
	}

	public WebElement getEmpDesig() {
		return empDesig;
	}

	public void setEmpDesig(String eDesig) {
		this.empDesig.sendKeys(eDesig);
	}

	public WebElement getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String eEmail) {
		this.empEmail.sendKeys(eEmail);
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton(WebElement submitButton) {
		this.submitButton = submitButton;
	}

	public WebElement getResetAll() {
		return resetAll;
	}

	public void setResetAll(WebElement resetAll) {
		this.resetAll = resetAll;
	}
		
}
