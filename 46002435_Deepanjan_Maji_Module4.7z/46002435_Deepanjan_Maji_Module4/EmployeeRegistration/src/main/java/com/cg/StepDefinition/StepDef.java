package com.cg.StepDefinition;

/**
 * @author Deepanjan Maji
 * @version 1.0
 */

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.cg.PageBean.ContactUsPage;
import com.cg.PageBean.HomePage;
import com.cg.PageBean.RegistrationPage;
import com.cg.PageBean.SuccessPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

//This is the Step Definition Class. All the steps of the test are defined here

public class StepDef 
{
	WebDriver driver;
	ContactUsPage cup;
	RegistrationPage reg,reg1;
	SuccessPage sp;
	HomePage hp;
	
	//PART ONE
	//Question 1 and 2
	
	@Given("^User is on Home Page$")
	public void user_is_on_Home_Page() throws Throwable 
	{
		//Setting the type and path of the browser driver
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\demaji\\Desktop\\Module 4\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		hp = PageFactory.initElements(driver, HomePage.class);
		//Maximizes the window size
		driver.manage().window().maximize();
		//Opens the required starting page
		driver.get("file:///D:/Users/demaji/Desktop/SET%20A/Home.html");
		Thread.sleep(1000);
	}
	
	//Question 3

	@Then("^Header should be \"([^\"]*)\"$")
	public void header_should_be(String arg1) throws Throwable 
	{
		String header_expected = hp.getHeader();
		assertEquals(header_expected, arg1);  //Checks the header of the Home Page
	}
	
	//Question 4

	@When("^User clicks on Contact Us link$")
	public void user_clicks_on_Contact_Us_link() throws Throwable 
	{
		hp.getContactUs().click();
		cup = PageFactory.initElements(driver, ContactUsPage.class);
		Thread.sleep(1000);
	}
	
	//Question 5

	@Then("^Title of Contact Us Page should be \"([^\"]*)\"$")
	public void title_of_Contact_Us_Page_should_be(String arg1) throws Throwable 
	{
		String title_expected = driver.getTitle();  //Checks the title of the Contact Us Page
		assertEquals(title_expected,arg1);
	}
	
	//Question 6
	
	@When("^User clicks on Register link$")
	public void user_clicks_on_Register_link() throws Throwable 
	{
		driver.get("file:///D:/Users/demaji/Desktop/SET%20A/Home.html");
		hp.getRegister().click();											//Redirects to registration page
		reg = PageFactory.initElements(driver, RegistrationPage.class);    
		Thread.sleep(1000);

	}
	
	//Question 7

	@Then("^Title of Registration Page should be \"([^\"]*)\"$")
	public void title_of_Registration_Page_should_be(String arg1) throws Throwable 
	{
		String title_expected = driver.getTitle();
		assertEquals(title_expected,arg1);
	}
	
	//Question 8
	
	@When("^User clicks on Submit button without entering any value$")
	public void user_clicks_on_Submit_button_without_entering_any_value() throws Throwable 
	{
		reg.setEmpName("");
		reg.getSubmitButton().click(); 
		Thread.sleep(1000);  
	}

	@Then("^Alert should be \"([^\"]*)\"$")
	public void alert_should_be(String arg1) throws Throwable 
	{
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, arg1);
		driver.switchTo().alert().accept();   //clicks the OK button   
	}
	
	//Question 9

	@When("^User clicks on Submit button without entering Employee Number$")
	public void user_clicks_on_Submit_button_without_entering_Employee_Number() throws Throwable 
	{
		reg.setEmpName("Deepanjan Maji");
		reg.getSubmitButton().click(); 
		Thread.sleep(1000);  
	    
	}

	@Then("^Alert displayed is \"([^\"]*)\"$")
	public void alert_displayed_is(String arg1) throws Throwable 
	{
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, arg1);
		driver.switchTo().alert().accept();   //clicks the OK button   
		
	}
	
	//Question 10
	
	@When("^User enters a character in Employee Number$")
	public void user_enters_a_character_in_Employee_Number() throws Throwable 
	{
	    reg.setEmpNumber("A");
	    Thread.sleep(1000);
	}

	@Then("^Message is displayed as \"([^\"]*)\"$")
	public void message_is_displayed_as(String arg1) throws Throwable 
	{
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, arg1);
		driver.switchTo().alert().accept();   //clicks the OK button
	}
	
	//Question 11
	
	@When("^User enters a character in Contact Number$")
	public void user_enters_a_character_in_Contact_Number() throws Throwable 
	{
		reg.setEmpNumber("1234");
		reg.setEmpContact("a");
		Thread.sleep(1000);  
	    
	}

	@Then("^Alert is displayed as \"([^\"]*)\"$")
	public void alert_is_displayed_as(String arg1) throws Throwable 
	{
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, arg1);
		driver.switchTo().alert().accept();   //clicks the OK button   
	}
	
	//Question 12

	@When("^User clicks on Submit button without selecting Job Location$")
	public void user_clicks_on_Submit_button_without_selecting_Job_Location() throws Throwable 
	{
		reg.setEmpContact("9870123465");
		reg.getSubmitButton().click(); 
		Thread.sleep(1000);  
	}

	@Then("^Alert is \"([^\"]*)\"$")
	public void alert_is(String arg1) throws Throwable 
	{
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, arg1);
		driver.switchTo().alert().accept();   //clicks the OK button   
	    
	}
	
	//Question 13

	@When("^User clicks on Submit button without entering Valid Email$")
	public void user_clicks_on_Submit_button_without_entering_Valid_Email() throws Throwable 
	{
		Select drploc = new Select(driver.findElement(By.name("location")));
        drploc.selectByVisibleText("Chennai");
	    reg.setEmpEmail("abc1234");
	    reg.getSubmitButton().click(); 
		Thread.sleep(1000);
	}

	@Then("^Message displayed is \"([^\"]*)\"$")
	public void message_displayed_is(String arg1) throws Throwable 
	{
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, arg1);
		driver.switchTo().alert().accept();   //clicks the OK button   
	}
	
	//Question 14
	
	@When("^User clicks on Submit button after entering all valid details$")
	public void user_clicks_on_Submit_button_after_entering_all_valid_details() throws Throwable 
	{
		reg.getEmpEmail().clear();;
		reg.setEmpEmail("abc1234@xyz.com");
	    reg.getSubmitButton().click(); 
		Thread.sleep(1000);
	}

	@Then("^Message is \"([^\"]*)\"$")
	public void message_is(String arg1) throws Throwable 
	{
		sp = PageFactory.initElements(driver, SuccessPage.class);
		String header_expected = sp.getsHeader();
		assertEquals(header_expected, arg1);
	}

	//Question 15
	
	@Then("^Title of Success Page should be \"([^\"]*)\"$")
	public void title_of_Success_Page_should_be(String arg1) throws Throwable 
	{
		String title_expected = driver.getTitle();
		assertEquals(title_expected,arg1);
		driver.quit();
	}
	
	//PART TWO
	//Question 1,2 and 3
	
	@Given("^User opens the Employee Registration Page$")
	public void user_opens_the_Employee_Registration_Page() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\demaji\\Desktop\\Module 4\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		//Maximizes the window size
		driver.manage().window().maximize();
		driver.get("file:///D:/Users/demaji/Desktop/SET%20A/EmployeeRegistration.html");
		reg1 = PageFactory.initElements(driver, RegistrationPage.class);
		Thread.sleep(1000);
	}
	
	@When("^User selects Employee name and number$")
	public void user_selects_Employee_name_and_number() throws Throwable 
	{
		reg1.setEmpName("Radhika");
		reg1.setEmpNumber("9822567212");
		Thread.sleep(2000);
	}

	//Question 5
	
	@Then("^name should be \"([^\"]*)\"$")
	public void name_should_be(String arg1) throws Throwable 
	{
		assertEquals("Radhika", arg1);
	}

	@Then("^password should be \"([^\"]*)\"$")
	public void password_should_be(String arg1) throws Throwable 
	{
		assertEquals("9822567212", arg1);
		driver.quit();
	}
}
