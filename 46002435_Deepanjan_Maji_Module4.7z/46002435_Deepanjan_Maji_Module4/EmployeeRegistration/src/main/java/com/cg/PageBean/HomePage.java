package com.cg.PageBean;

/**
 * 
 * @author Deepanjan Maji
 * @version 1.0
 */


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

//This is the POM for Home Page
public class HomePage 
{
	WebDriver driver;
	
	@FindBy(xpath = "/html/body/div/header/ul/li[1]/a")
	@CacheLookup
	WebElement home;
	
	@FindBy(xpath = "/html/body/div/header/ul/li[2]/a")
	@CacheLookup
	WebElement register;
	
	@FindBy(xpath = "/html/body/div/header/ul/li[3]/a")
	@CacheLookup
	WebElement contactUs;
	
	@FindBy(xpath = "/html/body/div/h1")
	@CacheLookup
	WebElement header;

	public String getHeader() {
		return header.getText();
	}

	public void setHeader(WebElement header) {
		this.header = header;
	}

	public HomePage(WebDriver driver) 
	{
		this.driver = driver;
	}

	public WebElement getHome() {
		return home;
	}

	public void setHome(WebElement home) {
		this.home = home;
	}

	public WebElement getRegister() {
		return register;
	}

	public void setRegister(WebElement register) {
		this.register = register;
	}

	public WebElement getContactUs() {
		return contactUs;
	}

	public void setContactUs(WebElement contactUs) {
		this.contactUs = contactUs;
	}
	
}
