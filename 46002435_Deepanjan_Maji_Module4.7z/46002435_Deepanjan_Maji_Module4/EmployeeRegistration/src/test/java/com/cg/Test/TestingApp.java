package com.cg.Test;

/**
 * @author Deepanjan Maji
 * @version 1.0
 */

//This is the Test Class
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)                                //Runs the test with the help of Cucumber
@CucumberOptions(glue = {"com.cg.StepDefinition"})      //Gives the path of Step Definition File
public class TestingApp 
{

}
