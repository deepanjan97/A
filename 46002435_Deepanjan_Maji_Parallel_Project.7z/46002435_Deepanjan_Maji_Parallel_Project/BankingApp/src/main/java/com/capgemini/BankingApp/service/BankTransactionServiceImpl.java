package com.capgemini.BankingApp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BankingApp.entity.Account;
import com.capgemini.BankingApp.entity.BankTransaction;
import com.capgemini.BankingApp.repository.AccountRepository;
import com.capgemini.BankingApp.repository.BankTransactionRepository;


@Service
public class BankTransactionServiceImpl implements BankTransactionService 
{
	
	@Autowired
	private BankTransactionRepository bankTransRep;
	@Autowired
	private AccountService accountService;
	@Autowired
	private AccountRepository accRep;

	@Override
	public List<BankTransaction> getAllTransactions() 
	{
		return (List<BankTransaction>) bankTransRep.findAll();
	}

	@Override
	public void addTransaction(BankTransaction bankTransc) 
	{
	
        List<Account> accounts =new ArrayList();
        if(bankTransc.getTransactionType().equalsIgnoreCase("debit")) 
        {
            accounts=accountService.getAllAccounts();
            for (Account a:accounts) 
            {
                if(a.getAccountNo() == bankTransc.getFromAccount()) 
                {
                	double amount = a.getAccountBalance()-bankTransc.getTransactionAmount();
                	a.setAccountBalance(amount);
                	accRep.save(a);
                	bankTransRep.save(bankTransc);
                }
            }
            
        }
        else if(bankTransc.getTransactionType().equals("credit")) 
        {
            accounts=accountService.getAllAccounts();
            for (Account a:accounts) 
            {
                if(a.getAccountNo() == bankTransc.getFromAccount()) 
                {
                	double amount = a.getAccountBalance()+bankTransc.getTransactionAmount();
                	a.setAccountBalance(amount);
                	accRep.save(a);
                	bankTransRep.save(bankTransc);
                }
            }  
        }
        else if(bankTransc.getTransactionType().equals("fund")) 
        {
            accounts=accountService.getAllAccounts();
            for (Account a:accounts) 
            {
                if(a.getAccountNo() == bankTransc.getFromAccount()) 
                {
                	double amount = a.getAccountBalance()-bankTransc.getTransactionAmount();
                	a.setAccountBalance(amount);
                	accRep.save(a);
                
                }
            }
            for (Account a1:accounts) 
            {
                 if(a1.getAccountNo() == bankTransc.getToAccount()) 
                 {
                    double amount = a1.getAccountBalance()+bankTransc.getTransactionAmount();
                    a1.setAccountBalance(amount);
                    accRep.save(a1);
                    
                 }
            }
            
        }
		
	}

	@Override
	public void deleteTransaction(int transid) 
	{
		bankTransRep.deleteById(transid);
	}

	@Override
	public Account depositTransact(int amount, long accNo) 
	{
		Account account = accountService.getAccount(accNo);
		account.setAccountBalance(account.getAccountBalance()+amount);
		return account;
	}

	@Override
	public Account withDrawTransact(int amount, long accNo) 
	{
		Account account = accountService.getAccount(accNo);
		account.setAccountBalance(account.getAccountBalance()-amount);
		return account;
	}

}
