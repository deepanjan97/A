package com.capgemini.BankingApp.service;

import java.util.List;

import com.capgemini.BankingApp.entity.Customer;



public interface CustomerService
{
	public List<Customer> getAllCustomers();
	
	public Customer getCustomer(long cid);
	
	public void addCustomer(Customer customer,int addressId);
	
	public void deleteCustomer(int customerId);
	
	public void updateCustomer(Customer customer, int customerId);
		
}
