package com.capgemini.BankingApp.service;

import java.util.List;

import com.capgemini.BankingApp.entity.Account;
import com.capgemini.BankingApp.entity.BankTransaction;

public interface BankTransactionService 
{
	
	public List<BankTransaction> getAllTransactions();
	
	public void addTransaction(BankTransaction bankTransc);
	
	public void deleteTransaction(int transid);
	
	public Account depositTransact(int amount,long accNo);
	
	public Account withDrawTransact(int amount,long accNo);
	
	

}
