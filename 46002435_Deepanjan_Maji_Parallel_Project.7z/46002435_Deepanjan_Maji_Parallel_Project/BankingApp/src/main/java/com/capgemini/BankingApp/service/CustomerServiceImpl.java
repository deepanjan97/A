package com.capgemini.BankingApp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BankingApp.entity.Address;
import com.capgemini.BankingApp.entity.Customer;
import com.capgemini.BankingApp.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService 
{
	
	@Autowired
	private CustomerRepository custRep;
	@Autowired
	private AddressService addrService;

	@Override
	public List<Customer> getAllCustomers() 
	{
		return (List<Customer>) custRep.findAll();
	}

	@Override
	public Customer getCustomer(long cid) 
	{
		List<Customer> customer = getAllCustomers();
		for(Customer c : customer) {
			if(c.getCustomerId()==cid) {
				return c;
			}
		}
		return null;
	}

	@Override
	public void addCustomer(Customer customer, int addressId) 
	{
		Address address=addrService.getAddress(addressId);
		customer.setAddress(address);
		custRep.save(customer);	
	}

	@Override
	public void deleteCustomer(int customerId) 
	{
		custRep.deleteById(customerId);	
	}

	@Override
	public void updateCustomer(Customer customer, int customerId) 
	{
		
		if(custRep.existsById(customerId))
		{
			List<Customer> customers=new ArrayList<>();
			custRep.findAll().forEach(customers::add);
			for(Customer c:customers) 
			{
				if(c.getCustomerId()==customerId) 
				{
					Address address=addrService.getAddress(c.getAddress().getAddressId());
					customer.setAddress(address);
					custRep.save(customer);
				}
			}
		}
		
	}
}
