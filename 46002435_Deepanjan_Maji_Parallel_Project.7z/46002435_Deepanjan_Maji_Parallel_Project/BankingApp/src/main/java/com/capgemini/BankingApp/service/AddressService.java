package com.capgemini.BankingApp.service;

import java.util.List;

import com.capgemini.BankingApp.entity.Address;



public interface AddressService 
{
	public List<Address> getAllAddress();
	
	public void addAddress(Address address);
	
	public Address getAddress(int aid);
	
	public void updateAddress(Address address, int aid);
	
	public void deleteAddress(int aid);
}
