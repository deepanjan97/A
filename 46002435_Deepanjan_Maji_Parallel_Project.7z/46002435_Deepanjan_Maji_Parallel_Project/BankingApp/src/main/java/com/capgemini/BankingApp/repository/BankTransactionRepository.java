package com.capgemini.BankingApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.BankingApp.entity.BankTransaction;

public interface BankTransactionRepository extends JpaRepository<BankTransaction, Integer> 
{

}
