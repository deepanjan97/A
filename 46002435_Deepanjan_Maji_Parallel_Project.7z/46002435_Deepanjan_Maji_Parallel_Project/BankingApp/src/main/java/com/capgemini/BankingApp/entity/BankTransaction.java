package com.capgemini.BankingApp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;


@Entity
public class BankTransaction 
{

	@Id
	@GeneratedValue
	private int trans_id;
	
	@Column(length = 15)
	@NotEmpty
	private String trans_date;
	
	private long fromAccount;
	
	private long toAccount;
	
	private int transactionAmount;
	
	@Column(length = 10)
	@NotEmpty
	private String transactionType;
	
	@OneToOne
	private Account account;
	
	//Getters and Setters

	public int getTrans_id() 
	{
		return trans_id;
	}

	public void setTrans_id(int trans_id) 
	{
		this.trans_id = trans_id;
	}

	public String getTrans_date() 
	{
		return trans_date;
	}

	public void setTrans_date(String trans_date) 
	{
		this.trans_date = trans_date;
	}

	public long getFromAccount() 
	{
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) 
	{
		this.fromAccount = fromAccount;
	}

	public long getToAccount() 
	{
		return toAccount;
	}

	public void setToAccount(long toAccount) 
	{
		this.toAccount = toAccount;
	}

	public int getTransactionAmount() 
	{
		return transactionAmount;
	}

	public void setTransactionAmount(int transactionAmount) 
	{
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionType() 
	{
		return transactionType;
	}

	public void setTransactionType(String transactionType) 
	{
		this.transactionType = transactionType;
	}

	public Account getAccount() 
	{
		return account;
	}

	public void setAccount(Account account) 
	{
		this.account = account;
	}
	
	//Default Constructor

	public BankTransaction() 
	{

	}

	//Parameterized Constructors
	
	public BankTransaction(int trans_id, String trans_date, long fromAccount, long toAccount, int transactionAmount,
			String transactionType, Account account) 
	{
		this.trans_id = trans_id;
		this.trans_date = trans_date;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.transactionAmount = transactionAmount;
		this.transactionType = transactionType;
		this.account = account;
	}
	
	
	
	
	
	
	

	
	
}
