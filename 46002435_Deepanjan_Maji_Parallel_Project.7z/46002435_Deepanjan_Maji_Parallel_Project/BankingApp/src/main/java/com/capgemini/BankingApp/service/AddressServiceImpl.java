package com.capgemini.BankingApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BankingApp.entity.Address;
import com.capgemini.BankingApp.repository.AddressRepository;


@Service
public class AddressServiceImpl implements AddressService 
{

	@Autowired
    private AddressRepository addrRepo;
	
	@Override
	public List<Address> getAllAddress() 
	{
		return (List<Address>) addrRepo.findAll();
	}

	@Override
	public void addAddress(Address address) 
	{
		addrRepo.save(address);
	}

	@Override
	public Address getAddress(int aid) 
	{
		List<Address> addressList = getAllAddress();
        for(Address a : addressList) {
            if(a.getAddressId() == aid) {
                return a;
            }
        }
        return null;
	}

	@Override
	public void updateAddress(Address address, int aid)
	{
		address.setAddressId(aid);
        addrRepo.save(address);
	}

	@Override
	public void deleteAddress(int aid) 
	{
		addrRepo.deleteById(aid);
	}

}
