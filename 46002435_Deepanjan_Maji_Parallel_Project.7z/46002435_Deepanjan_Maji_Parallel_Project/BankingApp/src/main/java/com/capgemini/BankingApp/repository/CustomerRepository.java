package com.capgemini.BankingApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.BankingApp.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> 
{

}
