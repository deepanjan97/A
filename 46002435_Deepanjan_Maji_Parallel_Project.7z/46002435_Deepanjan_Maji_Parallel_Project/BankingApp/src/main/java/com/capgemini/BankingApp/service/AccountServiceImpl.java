package com.capgemini.BankingApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BankingApp.entity.Account;
import com.capgemini.BankingApp.entity.Customer;
import com.capgemini.BankingApp.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService 
{
	@Autowired
	private AccountRepository accRep;
	
	@Autowired
	private CustomerService custService;

	@Override
	public List<Account> getAllAccounts() 
	{
		return  (List<Account>) accRep.findAll();
	}

	@Override
	public Account getAccount(long acc_id) 
	{
		List<Account> accounts = getAllAccounts();
		for(Account ac : accounts) 
		{
			if(ac.getAccountNo()==acc_id) 
			{
				return ac;
			}
		}
		return null;
	}

	@Override
	public void updateAccount(long acc_id, Account account) 
	{
		account.setAccountNo(acc_id);
		List<Customer> customers = custService.getAllCustomers();
		Account ac = getAccount(acc_id);
		int customer_id = ac.getCustomer().getCustomerId();
		for(Customer c: customers) {
			if(c.getCustomerId()==customer_id) {
				account.setCustomer(c);
			}
		}
		accRep.save(account);	
	}

	@Override
	public void addAccount(Account account, long cid) 
	{
		Customer customer = custService.getCustomer(cid);
		account.setCustomer(customer);
		accRep.save(account);
	}

	@Override
	public void deleteAccount(long acc_id) 
	{
		accRep.deleteById(acc_id);
	}
	
}
