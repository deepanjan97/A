package com.capgemini.BankingApp.service;

import java.util.List;

import com.capgemini.BankingApp.entity.Account;


public interface AccountService 
{

	public List<Account> getAllAccounts();
	
	public Account getAccount(long acc_id);
	
	public void updateAccount(long acc_id, Account account);
	
	public void addAccount(Account account, long cid);
	
	public void deleteAccount(long acc_id);
		
}
